<?php var_dump(function_exists('pg_connect'));
